import json
import os
from pathlib import Path

from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import tornado

class RouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self):
        self.finish(json.dumps({
            "data": "This is /getml_extension/get_example endpoint!"
        }))

def get_environment(getml_dir):
    getml_dir = Path(getml_dir).expanduser()
    getml_env_file = getml_dir / "getml-0.15.0-beta-macos/environment.json"

    env = dict()
    env["binder_ref"] = os.environ.get("BINDER_REF_URL")
    env["binder_request"] = os.environ.get("BINDER_REQUEST")
    env["client_id"] = os.environ.get("JUPYTERHUB_CLIENT_ID")
    env["jupyter_image"] = os.environ.get("JUPYTER_IMAGE") if os.environ.get("JUPYTER_IMAGE") is not None else ''
    env["binder_cluster"] = env["jupyter_image"].split("/")[0]

    with open(getml_env_file) as f:
        getml_env = json.load(f)
        env["license_seed"] = getml_env["monitor"]["licenseSeedStatic"]
        env["getml_env"] = getml_env

    return env

class GetEnvHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self):
        env = get_environment("~/.getML")
        self.finish(json.dumps(env))   

def setup_handlers(web_app):
    host_pattern = ".*$"

    base_url = web_app.settings["base_url"]
    route_pattern = url_path_join(base_url, "getml_extension", "get_example")
    handlers = [(route_pattern, RouteHandler)]
    # web_app.add_handlers(host_pattern, handlers)
    web_app.add_handlers(host_pattern, [(url_path_join(base_url, "getml_extension", "get_env"), GetEnvHandler)])    
